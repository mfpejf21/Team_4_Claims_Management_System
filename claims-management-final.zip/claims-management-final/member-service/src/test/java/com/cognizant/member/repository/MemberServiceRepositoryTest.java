package com.cognizant.member.repository;

public class MemberServiceRepositoryTest {

}